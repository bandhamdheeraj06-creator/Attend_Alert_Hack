ATTENDALERT HACK — DEMO WEBSITE

PROJECT STRUCTURE
- index.html       Main page structure
- css/style.css    Red and black theme, layout and responsive styling
- js/script.js     Sample data, attendance logic, risk levels and interactions

HOW TO RUN
1. Extract the ZIP file.
2. Keep index.html, css/ and js/ together in the same folder.
3. Open index.html in Chrome, Edge or Firefox.
4. No installation or server is required for this frontend demo.

FEATURES INCLUDED
- Mentor overview with student count, safe/warning/critical totals and class average.
- Five sample subjects and 30 sample engineering students.
- Faculty attendance marking: Present, Absent and Late; Mark all present; save session.
- Live attendance percentage recalculation after saving a session.
- Risk classification: Safe >=75%, Warning 65–74%, Critical <65%.
- Recovery estimate using ceil((0.75 * total held - attended) / 0.25).
- Mentor alert queue with intervention notes.
- Student self-service demo portal with subject-wise status.
- CSV export of at-risk students.
- Dark mode by default with a light-mode toggle.
- Browser localStorage saves demo attendance and intervention records.

IMPORTANT DEMO LIMITATIONS
- This is a frontend prototype. It does not include a real login, server, database or role-based access control.
- Data is stored in the current browser only. It is not shared between faculty and student devices.
- The student portal uses a demo student selector; it is not secure authentication.
- Email alerts are not sent. The mentor alert hub simulates the notification workflow.
- Late is counted as attended in this demo. Change the rule in js/script.js if your institution treats late differently.
- Recovery estimates are calculated per subject. The formula assumes every future class attended adds one to both attended and held.
- Sample names and attendance figures are fictional demonstration data. Replace them with authorised roster data for a real deployment.
